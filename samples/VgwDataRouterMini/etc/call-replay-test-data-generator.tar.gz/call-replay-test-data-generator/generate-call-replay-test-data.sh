#!/bin/bash
# ========================
# First created on: Jun/04/2020
# Last modified on: Jul/05/2020
#
# This script can be used to generate test data required to
# replay the pre-recorded voice calls for use with the
# VoiceGatewayToStreamsToWatsonS2T or with the 
# VoiceGatewayToStreamsToWatsonSTT application.
# This script generates as many replayable calls as needed 
# by using the sample template files belonging to a generic, 
# non-confidential, pre-recorded voice call. It also creates 
# another shell-script named replay-now.sh which can be run
# to create the replay signal files for the generated test calls.
#
# Before using this script, you should start your IBM Streams
# application with the call replay and optionally the 
# call recording enabled with their corresponding directories.
# Then, you can copy this script and the other four template
# files found in the same tar.gz file that contains this script
# into your call replay directory. When you are ready to
# generate replayable test voice call files, you can run
# this script.
# e-g: ./generate-call-replay-test-data.sh  -t 20
# After this script runs to complettion, then you can run
# ./replay-now.sh which will start replaying the generated
# test calls which will get picked up by your running
# application to do a trascription of the calls.
# ========================
#
# Initialize an array to store the unique voice call session ids.
vgw_session_id_array=()
# This holds the total number of replayable calls to be generated.
toal_calls_needed=0
# Get a random multiplier that we will use for 
# creating unique VGW session ids.
random_multiplier=$(((RANDOM%100+1)))
# Number of command line options to shift out
s=0 

while getopts "t:h" options; do
    case $options in
    t) toal_calls_needed=$OPTARG
       let s=s+2
       ;;
    h | * ) echo "
Command line arguments
  -t INTEGER      totalCallsNeeded   (1 to 500)

  e-g:
  -t 100
"
        exit 1
        ;;
    esac
done
shift $s

# Validate the total calls needed value as entered by the user.
if [ $toal_calls_needed -le 0 ] ||  [ $toal_calls_needed -gt "500" ];
then
   echo "Missing or wrong value for total calls needed via the -t option."
   echo "Please specify a number from 1 to 500."
   echo ""
   echo "Get help using -h option."
   exit 1
fi

# ================
# echo $total_calls_needed
# exit 1
# ================
current_time=`date`
start_msg="Start time: "
start_msg="$start_msg$current_time"
echo $start_msg
# ================
# At first, let us check if the template (sample) pre-recorded voice call files are present.
# We should have 4 files (2 metadata JSON files and 2 mulaw bin files).
# These 4 files represent the two voice channels (agent and customer) in a voice call.
if [ ! -f vc1-md-json.txt ]; then
    echo "No voice channel 1 metadata JSON template file found."
    exit 1
fi

if [ ! -f vc1-ml-bin.raw ]; then
    echo "No voice channel 1 mulaw binary template file found."
    exit 1
fi

if [ ! -f vc2-md-json.txt ]; then
    echo "No voice channel 2 metadata JSON template file found."
    exit 1
fi

if [ ! -f vc2-ml-bin.raw ]; then
    echo "No voice channel 2 mulaw binary template file found."
    exit 1
fi

# Now stay in a loop and generate as many replayable calls as the user asked for.
for (( callIdx=0; callIdx<$toal_calls_needed; callIdx++ ))
do
   # Get a random number to be used as a vgwSessionId
   random_value=$(( RANDOM * random_multiplier ))
   vgw_session_id=""
   vgw_session_id="$vgw_session_id$random_value"

   # Make a copy of the binary template files for the two voice channels.
   vc1_ml_file_name="$vgw_session_id-1-mulaw.bin"
   cp ./vc1-ml-bin.raw $vc1_ml_file_name
   vc2_ml_file_name="$vgw_session_id-2-mulaw.bin"
   cp ./vc2-ml-bin.raw $vc2_ml_file_name
   
   # Make a copy of the metadata JSON template files for the two voice channels.
   vc1_md_file_name="$vgw_session_id-1-metadata.json"
   cp ./vc1-md-json.txt $vc1_md_file_name
   vc2_md_file_name="$vgw_session_id-2-metadata.json"
   cp ./vc2-md-json.txt $vc2_md_file_name
   
   # Change the vgwSessionId field in the JSON file for the two voice channels.
   sed_body="s/12345678/"
   sed_body="$sed_body$vgw_session_id"
   global_option="/g"
   sed_body="$sed_body$global_option"
   sed -i -e $sed_body $vc1_md_file_name
   sed -i -e $sed_body $vc2_md_file_name
   # Add the vgwSessionId to the array for later use.
   vgw_session_id_array[$callIdx]=$vgw_session_id
done

# Let us now create a shell script to signal the replay of the calls generated above.
rm -f ./replay-now.sh
# Add the bash script header shebang line.
echo "#!/bin/bash" > ./replay-now.sh

# Stay in a loop and add a touch command to create a signal file for every call.
for (( callIdx=0; callIdx<$toal_calls_needed; callIdx++ ))
do
   vgw_session_id=${vgw_session_id_array[$callIdx]}
   touch_body="touch "
   touch_body="$touch_body$vgw_session_id"
   mulaw_extension=".process-mulaw"
   touch_body="$touch_body$mulaw_extension"
   echo $touch_body >> ./replay-now.sh
done

echo "date" >> ./replay-now.sh
# Make it executable
chmod u+x ./replay-now.sh

status_msg="Generated "
status_msg="$status_msg$toal_calls_needed"
status_msg2=" replayable voice call(s) for your use."
status_msg="$status_msg$status_msg2"
echo $status_msg

current_time=`date`
end_msg="End time: "
end_msg="$end_msg$current_time"
echo $end_msg
